from .models import Anketa
from .serializers import TaskSerializer
from rest_framework.response import Response
from rest_framework.decorators import api_view


@api_view(['GET'])
def AnketaDetail(request):
    x = request.data("x")
    y = request.data("y")
    checker = 0
    for i in Anketa:
        if x == Anketa.coordinatesx and y == Anketa.coordinatesy:
            pk = Anketa.id
            checker += 1
            anketas = Anketa.objects.get(id=pk)
            serializer = TaskSerializer(anketas, many=False)
            return Response(serializer.data)
    if checker == 0:
        return Response("Пусто")


@api_view(['DELETE'])
def AnketaDelete(request, pk):
    anketa = Anketa.objects.get(id=pk)
    anketa.delete()

    return Response('Item succsesfully delete!')


@api_view(['POST'])
def AnketaUpdate(request, pk):
    anketa = Anketa.objects.get(id=pk)
    serializer = TaskSerializer(instance=anketa, data=request.data)

    if serializer.is_valid():
        serializer.save()

    return Response(serializer.data)


@api_view(['POST'])
def AnketaCreate(request):
    serializer = TaskSerializer(data=request.data)

    if serializer.is_valid():
        serializer.save()

    return Response(serializer.data)


@api_view(['GET'])
def AnketaList(request):
	anketas = Anketa.objects.all().order_by('id')
	serializer = TaskSerializer(anketas, many=True)
	return Response(serializer.data)

