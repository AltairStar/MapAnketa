from rest_framework import serializers
from .models import Anketa

class TaskSerializer(serializers.ModelSerializer):
	class Meta:
		model = Anketa
		fields ='__all__'