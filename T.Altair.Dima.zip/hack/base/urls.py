from . import views
from django.urls import path
from django.views.generic import TemplateView
from django.contrib import admin


urlpatterns = [
    path('index/', TemplateView.as_view(template_name="base/index.html"),name="index"),
    path('anketa/', TemplateView.as_view(template_name="base/anketa.html"),name="anketa"),
    path('anketa-detail/<str:pk>/', views.AnketaDetail),
    path('anketa-create/',views.AnketaCreate),
    path('anketa-update/<int:pk>/', views.AnketaUpdate),
    path('anketa-delete/<int:pk>/', views.AnketaDelete),
    path('anketa-list', views.AnketaList),
]
