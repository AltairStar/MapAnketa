from django.db import models
from django.contrib.auth.models import User


class Anketa(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    name = models.CharField(max_length=30, blank=True, null=True)
    surname = models.CharField(max_length=50, blank=True, null=True)
    thirdname = models.CharField(max_length=50, blank=True, null=True)
    iin = models.CharField(max_length=50, blank=True, null=True)
    city = models.CharField(max_length=50, blank=True, null=True)
    street = models.CharField(max_length=100, blank=True, null=True)
    numofhouse = models.IntegerField( blank=True, null=True)
    numofapart = models.IntegerField(null=True)
    kadnumber = models.CharField(max_length=100, blank=True, null=True)
    area = models.CharField(max_length=100, null=True)
    coordinatesx = models.CharField(max_length=200, blank=True, null=True)
    coordinatesy = models.CharField(max_length=200, blank=True, null=True)
    info = models.TextField(null=True, blank=True)#


    def __str__(self):
        return self.surname

    class Meta:
        ordering = ['surname']

