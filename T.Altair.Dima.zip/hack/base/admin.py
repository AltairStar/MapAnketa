from django.contrib import admin
from .models import Anketa

admin.site.register(Anketa)
