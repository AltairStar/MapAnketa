var recognizer = new webkitSpeechRecognition();
recognizer.interimResults = true;
recognizer.lang = 'ru-Ru';

recognizer.onresult = function (event) {
  var result = event.results[event.resultIndex];

  if (result.isFinal) {
    console.log(result[0].transcript)
    findTask(result[0].transcript);
  }
};

function speech() {
  recognizer.start();
}

function findTask(result) {
  var synth = window.speechSynthesis;
  if (result == "Привет") {
    var utterance = new SpeechSynthesisUtterance("Приветсвую")
    synth.speak(utterance);
  }
  else if (result == "список анкет") {
    var utterance = new SpeechSynthesisUtterance("Перехожу к списком анкет")

    synth.speak(utterance);
    document.location.href = "../anketa";
  }
  else {
 var utterance = new SpeechSynthesisUtterance("Не удолось обработать голос")

    synth.speak(utterance);
  }

}