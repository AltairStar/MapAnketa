


async function updateData(data) {
    const response = await fetch(url, {
        method: 'POST', // *GET, POST, PUT, DELETE,
        body: JSON.stringify(data)
    });
    return await response.json();
}


async function GetData(data) {
    const response = await fetch(url, {
        method: 'GET', // *GET, POST, PUT, DELETE, 
        body: JSON.stringify(data)
    });
    return await response.json();
}
async function GetDataList() {
    const response = await fetch("http://127.0.0.1:8000/anketa-list", {
        method: 'GET', // *GET, POST, PUT, DELETE, 
    });
    return await response.json();
}
anketa()
async function anketa(){
//    document.getElementById('anketa')
var arr = await GetDataList()

for(let i =0;i<arr.length;i++){
let div = document.createElement('div');
div.className = "card";
var cardbody = document.createElement('div');
cardbody.className = "card-body";

div.append(cardbody)

var h = document.createElement('h5');
h.className = "card-title ";
h.innerHTML = "ID: "+arr[i]['id']
cardbody.append(h)
var p = document.createElement('p');
p.className = "card-text";
p.innerHTML = "ФИО: "+ arr[i]['name']+" "+arr[i]['surname']+" "+arr[i]['thirdname']
cardbody.append(p)
var kadnumber = document.createElement('p');
kadnumber.className = "card-text";
kadnumber.innerHTML = "Кадастровый номер: : "+arr[i]['kadnumber']
cardbody.append(kadnumber)
var area = document.createElement('p');
area.className = "card-text";
area.innerHTML = "Площадь номер: : "+arr[i]['area']
cardbody.append(area)
//var d =  document.createElement('div');
//d.innerHTML = arr[i]['id'] + " " + arr[i]['name']+" "+arr[i]['surname']+" "+arr[i]['thirdname']+" "+arr[i]['kadnumber']+" "+arr[i]['area']
//cardbody.append(d)
document.body.append(div);

}
}