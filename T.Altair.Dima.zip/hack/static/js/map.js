ymaps.ready(init);

function init() {
    var myPlacemark,
        myMap = new ymaps.Map('map', {
            center: [48, 66.622093],
            zoom: 4
        }, {
            searchControlProvider: 'yandex#search',
            restrictMapArea: true
        });

    // Слушаем клик на карте.
    myMap.events.add('click', function (e) {
        var coords = e.get('coords');
        console.log(coords)
        // Если метка уже создана – просто передвигаем ее.
        if (myPlacemark) {
            myPlacemark.geometry.setCoordinates(coords);
        }
        // Если нет – создаем.
        else {
            myPlacemark = createPlacemark(coords);
            myMap.geoObjects.add(myPlacemark);
            // Слушаем событие окончания перетаскивания на метке.
            myPlacemark.events.add('dragend', function () {
                getAddress(myPlacemark.geometry.getCoordinates());
            });
        }
        getData(coords);
    });

    myMap.controls.remove('geolocationControl');
    myMap.controls.remove('searchControl');
    myMap.controls.remove('trafficControl');
    // myMap.controls.remove('typeSelector');
    myMap.controls.remove('fullscreenControl');
    myMap.controls.remove('rulerControl');
    // myMap.behaviors.disable(['scrollZoom']);
    var fullscreenControl = new ymaps.control.FullscreenControl();
    myMap.controls.add(fullscreenControl);
    fullscreenControl.enterFullscreen();

    // Создание метки.
    function createPlacemark(coords) {
        return new ymaps.Placemark(coords, {
            iconCaption: 'Не известный адресс'
        }, {
            preset: 'islands#violetDotIconWithCaption',
            draggable: true
        });
    }


    function getData(coords) {
        document.getElementsByClassName('sidebar')[0].style.visibility = 'visible'
        document.getElementById('x').value= coords[0]
        document.getElementById('y').value = coords[1]
    console.log(coords[0])
    }

}
function close() {
    document.getElementsByClassName('sidebar')[0]
        .style.visibility = 'hidden'
}
